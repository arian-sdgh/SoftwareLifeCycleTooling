//non-compiled with javac: compiling on jdk before 8
//more details at https://github.com/checkstyle/checkstyle/issues/7846
@Deprecated
package com.puppycrawl.tools.checkstyle.checks.annotation.packageannotation; // warn

public class InputXpathPackageAnnotationOne {

}
