// non-compiled with javac: missing package. Used for Testing purpose.
// package is missing.
public class InputXpathMissingPackage { // warn
	// code
}
