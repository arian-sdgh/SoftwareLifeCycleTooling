package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

/** Some javadoc. */
public class InputFormattedOrderingAndSpacingNoImports {}
